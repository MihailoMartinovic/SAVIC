# Example Package

This is SAVIC package. The documentation is available at

https://savic.readthedocs.io/en/latest/
